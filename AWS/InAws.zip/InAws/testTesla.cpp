#include <iostream>
#include <boost/math/distributions/normal.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/math/tools/roots.hpp>
#include <boost/random.hpp>
#include <boost/random/variate_generator.hpp>
#include <boost/math/distributions/uniform.hpp>
#include <boost/random/discrete_distribution.hpp>
#include <ctime>
#include <cmath>
#include <fstream>
#include <armadillo>
#include <iomanip>
#include <math.h>
#include <sstream>
#include <string>
#include <stdio.h>
#include <vector>
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <random>
#include <unistd.h>
#include <nlopt.hpp>
#include <utility>
//#include <Rcpp.h> -> Not necessary if rcpparmadillo included
//#include <RcppArmadillo.h>
//#include <bits/stdc++.h>

using std::vector;
using namespace std;


double algo(double x){
    ofstream TEST;
    cout << " ------distance computing, now saving2 "<< endl;
    TEST.open("test22.txt", std::ios_base::app);
    cout << " ------distance computing, now saving 3"<< endl;
    TEST<<  2 << " , " ;
    cout << " ------distance computing, now saving4 "<< endl;
    cout << " aaaa "<< endl;
    
    
    TEST << endl;
    cout << " ------distance computing, now saving 5"<< endl;
    TEST.close();
    cout << " ------distance computing, now saving 66"<< endl;
    return(x);
}


int main(int argc, const char * argv[]) {
    
    vector<double> A(3);
    vector<double> V(3);
    V[0]=0;
    V[1]=1;
    V[2]=2;
    A[0]=50;
    A[1]=40;
    A[2]=30;
    
    int x=0;
    //std::iota(V.begin(),V.end(),x++); //Initializing
    //sort( V.begin(),V.end(), [&](int i,int j){return A[i]<A[j];} );
    cout << A[0] << " A[0]"<< endl;
    cout << A[1] << " A[1]"<< endl;
    cout << A[2] << " A[2]"<< endl;
    cout << V[0] << " V[0]"<< endl;
    cout << V[1] << " V[1]"<< endl;
    cout << V[2] << " V[2]"<< endl;
    double test=0;
    for(int it=0; it<10; it++){
     test=algo(3.4);
        cout << test << " test "<< endl;
        cout << it << " it "<< endl;
    }
    cout << test << " test "<< endl;
    ofstream TEST;
    cout << " ------distance computing, now saving2 "<< endl;
    TEST.open("test.txt", std::ios_base::app);
    cout << " ------distance computing, now saving 3"<< endl;
    TEST<<  2 << " , " ;
    cout << " ------distance computing, now saving4 "<< endl;
    
    
    
    TEST << endl;
    cout << " ------distance computing, now saving 5"<< endl;
    TEST.close();
    cout << " ------distance computing, now saving 66"<< endl;
    
    
    cout << "Hello, World!\n";
    return 0;
}

